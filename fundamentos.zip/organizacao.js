console.log("Sentença de código");
{
    console.log("Olá mundo!")
    console.log("salve salve yodinha")
    {
        console.log('cursinho')
    }
}