const prod1 = {}
prod1.nome = 'Celular Ultra mega'
prod1.preco = 4998,00
prod1['Desconto Legal'] = 0.40 
console.log(prod1)

const prod2 = {
    nome: 'Camisa Polo',
    preco: 79.90
}
console.log(prod2)