// barra barra para comentário de uma linha
console.log('Linha1')

/* barra asterisco / asterisco barra
para comentários de várias linhas 
*/
console.log('Linha2!')
