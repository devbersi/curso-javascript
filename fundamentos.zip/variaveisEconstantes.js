var a = 3 
// var=variavel a=identificador ==recebe 3=valor da variavel
var b = 4

var c = b + a  

console.log(c)