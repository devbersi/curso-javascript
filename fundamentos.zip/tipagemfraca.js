let qualquer = 'Legal'
console.log(qualquer)
console.log(typeof qualquer)

qualquer = 13.15
console.log(qualquer)
console.log(typeof qualquer)

//evitar nomes e siglas
let valor = ''
let numero = 1
let pqp = false // produto quimico perigoso...